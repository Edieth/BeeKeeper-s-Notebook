package Entity

class Inventory {
}